﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ConsoleTamagotchiApp.DataTransferObjects;
using System.Threading.Tasks;

namespace ConsoleTamagotchiApp
{
    class Play : Screen
    {
        public Play() : base("play with your pet")
        {
        }
    }
       
}
