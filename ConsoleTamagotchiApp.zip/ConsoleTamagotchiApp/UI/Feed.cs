﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ConsoleTamagotchiApp.DataTransferObjects;
using System.Threading.Tasks;

namespace ConsoleTamagotchiApp
{
    class Feed : Screen
    {
        public Feed() : base("Feed Your Pet! \n")
        {
        }

      
    }
}
